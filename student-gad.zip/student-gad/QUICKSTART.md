## Quick Start Guide

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Setup MySQL Database
1. Open MySQL Workbench or MySQL command line
2. Copy and paste the entire SQL database creation script
3. Execute the script to create the `student_gadget_system` database

### Step 3: Configure Database Connection
Edit `config/database.js`:
```javascript
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'YOUR_MYSQL_PASSWORD',  // ← Add your password here
  database: 'student_gadget_system',
  port: 3306,
  // ... rest stays the same
});
```

### Step 4: Start the Server
```bash
npm start
```

You should see:
```
Server running on http://localhost:3000
```

### Step 5: Access the Application
Open your browser and go to:
- **Home**: http://localhost:3000
- **Dashboard**: http://localhost:3000/dashboard
- **Students**: http://localhost:3000/students
- **Gadgets**: http://localhost:3000/gadgets
- **Incidents**: http://localhost:3000/incidents

### Available Pages

#### 1. **Home Page** (/)
- Overview of the system
- Quick statistics
- Navigation to main features

#### 2. **Dashboard** (/dashboard)
- Real-time statistics
- Recent registrations
- Expiring gadgets
- Gadgets by category
- Incidents by type

#### 3. **Students** (/students)
- View all students
- Add new student
- Edit student information
- Delete student records
- Filter by department

#### 4. **Gadgets** (/gadgets)
- View all registered gadgets
- Register new device
- Edit gadget details
- Delete registration
- Track warranty and insurance

#### 5. **Incidents** (/incidents)
- View all incident reports
- Report new incident
- Update incident status
- Link to student and gadget
- Track resolution

### Key Features to Try

1. **Add a Student**
   - Go to Students page
   - Click "Add New Student"
   - Fill in all required fields
   - Click Save

2. **Register a Gadget**
   - Go to Gadgets page
   - Click "Register New Gadget"
   - Select student ID and category
   - Add device details
   - Click Save

3. **Report an Incident**
   - Go to Incidents page
   - Click "Report Incident"
   - Select student and their gadget
   - Describe the incident
   - Click Save

4. **View Dashboard**
   - Go to Dashboard
   - See real-time statistics
   - Check expiring gadgets
   - View incident trends

### Database Structure

The system includes:
- 8 main tables
- Proper relationships with foreign keys
- Indexes for performance
- Sample data included

### Sample Data Available

The database comes with sample data including:
- 10 students across 5 departments
- 10 registered gadgets
- Sample incidents
- Department information

### Troubleshooting

**Port 3000 already in use:**
```bash
# Change port in server.js
const PORT = process.env.PORT || 3001;
```

**MySQL Connection Error:**
- Verify MySQL is running
- Check username and password
- Ensure database exists
- Check port (default: 3306)

**Database script won't run:**
- Copy paste line by line
- Check for syntax errors
- Ensure MySQL user has create privileges

### API Base URL
```
http://localhost:3000/api
```

### Development Tips

1. **Browser DevTools** - Use F12 to inspect network requests
2. **Console Logs** - Check browser console for errors
3. **MySQL Workbench** - Monitor database from GUI
4. **Postman** - Test API endpoints

### File Locations

- **Frontend**: `public/` folder
- **Backend**: `routes/` folder
- **Database Config**: `config/database.js`
- **Server**: `server.js`

### Important Notes

- All dates use YYYY-MM-DD format
- Status fields: Active/Inactive, Pending/Resolved, etc.
- File uploads not implemented (enhance as needed)
- Authentication not included (add as needed)
- Ensure MySQL port is accessible

Enjoy using the Student Gadget Management System! 🎓📱
