const express = require('express');
const path = require('path');
const cors = require('cors');

// Import routes
const studentsRouter = require('./routes/students');
const gadgetsRouter = require('./routes/gadgets');
const incidentsRouter = require('./routes/incidents');
const departmentsRouter = require('./routes/departments');
const dashboardRouter = require('./routes/dashboard');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/api/students', studentsRouter);
app.use('/api/gadgets', gadgetsRouter);
app.use('/api/incidents', incidentsRouter);
app.use('/api/departments', departmentsRouter);
app.use('/api/dashboard', dashboardRouter);

// Serve static HTML pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/students', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'students.html'));
});

app.get('/gadgets', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'gadgets.html'));
});

app.get('/incidents', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'incidents.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('Available routes:');
  console.log('  GET /');
  console.log('  GET /students');
  console.log('  GET /gadgets');
  console.log('  GET /incidents');
  console.log('  GET /dashboard');
  console.log('  API routes:');
  console.log('  /api/students - Student management');
  console.log('  /api/gadgets - Gadget registration management');
  console.log('  /api/incidents - Incident report management');
  console.log('  /api/departments - Department management');
  console.log('  /api/dashboard - Dashboard statistics');
});

module.exports = app;
