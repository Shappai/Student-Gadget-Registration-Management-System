const mysql = require('mysql2/promise');

// Create connection pool
// TODO: Add your database URL here. Example: 'mysql://root:password@localhost:3306/student_gadget_system'
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'adeniran', 
  database: 'student_gadget_system',
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

module.exports = pool;
