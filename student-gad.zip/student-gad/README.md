# Student Gadget Registration Management System

A comprehensive web application for managing student gadget registrations, tracking incidents, and maintaining records of all registered devices within an educational institution.

## Features

- **Student Management** - Register and manage student profiles with contact information
- **Gadget Registration** - Track all registered devices with warranty and insurance information
- **Incident Reporting** - Report and track incidents (lost, stolen, damaged devices)
- **Dashboard Analytics** - Real-time statistics and visualizations
- **Department Organization** - Organize students and gadgets by department
- **Warranty & Insurance Tracking** - Manage warranty and insurance policies

## Project Structure

```
student-gad/
├── config/
│   └── database.js           # MySQL database configuration
├── routes/
│   ├── students.js           # Student CRUD operations
│   ├── gadgets.js            # Gadget registration management
│   ├── incidents.js          # Incident report management
│   ├── departments.js        # Department management
│   └── dashboard.js          # Dashboard statistics endpoints
├── public/
│   ├── css/
│   │   └── style.css         # Main stylesheet (fully styled)
│   ├── js/
│   │   ├── main.js           # Home page functionality
│   │   ├── students.js       # Student management UI
│   │   ├── gadgets.js        # Gadget management UI
│   │   ├── incidents.js      # Incident reporting UI
│   │   └── dashboard.js      # Dashboard UI
│   ├── index.html            # Home page
│   ├── students.html         # Student management page
│   ├── gadgets.html          # Gadget management page
│   ├── incidents.html        # Incident reporting page
│   └── dashboard.html        # Dashboard page
├── server.js                 # Express server entry point
├── package.json              # NPM dependencies
└── README.md                 # This file
```

## Prerequisites

- Node.js (v14 or higher)
- MySQL Server (v5.7 or higher)
- npm (comes with Node.js)

## Installation

### 1. Install Dependencies

```bash
npm install
```

This will install:
- `express` - Web server framework
- `cors` - Cross-Origin Resource Sharing
- `mysql2` - MySQL database driver

### 2. Create MySQL Database

Run the provided SQL script to create the database and tables:

```sql
-- Copy and paste the entire SQL script provided in the project documentation
-- This creates the student_gadget_system database with all required tables
```

### 3. Configure Database Connection

Edit `config/database.js` and update the connection settings:

```javascript
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'your_password_here', // Add your MySQL password
  database: 'student_gadget_system',
  port: 3306,
  // ... rest of configuration
});
```

## Running the Application

### Start the Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

The server will start on `http://localhost:3000`

### Access the Application

Open your browser and navigate to:

- **Home**: http://localhost:3000/
- **Dashboard**: http://localhost:3000/dashboard
- **Students**: http://localhost:3000/students
- **Gadgets**: http://localhost:3000/gadgets
- **Incidents**: http://localhost:3000/incidents

## API Endpoints

### Students
- `GET /api/students` - Get all students
- `GET /api/students/:id` - Get student by ID
- `POST /api/students` - Create new student
- `PUT /api/students/:id` - Update student
- `DELETE /api/students/:id` - Delete student
- `GET /api/students/department/:dept_code` - Get students by department

### Gadgets
- `GET /api/gadgets` - Get all gadget registrations
- `GET /api/gadgets/:id` - Get gadget by registration ID
- `POST /api/gadgets` - Register new gadget
- `PUT /api/gadgets/:id` - Update gadget registration
- `DELETE /api/gadgets/:id` - Delete gadget registration
- `GET /api/gadgets/student/:student_id` - Get gadgets by student
- `GET /api/gadgets/categories/all` - Get all gadget categories

### Incidents
- `GET /api/incidents` - Get all incident reports
- `GET /api/incidents/:id` - Get incident by ID
- `POST /api/incidents` - Create incident report
- `PUT /api/incidents/:id` - Update incident report
- `DELETE /api/incidents/:id` - Delete incident
- `GET /api/incidents/student/:student_id` - Get incidents by student
- `GET /api/incidents/status/:status` - Get incidents by status
- `GET /api/incidents/stats/all` - Get incident statistics

### Departments
- `GET /api/departments` - Get all departments
- `GET /api/departments/:code` - Get department by code
- `POST /api/departments` - Create department
- `PUT /api/departments/:code` - Update department
- `DELETE /api/departments/:code` - Delete department
- `GET /api/departments/:code/students` - Get students in department
- `GET /api/departments/:code/stats` - Get department statistics

### Dashboard
- `GET /api/dashboard/stats` - Get overall statistics
- `GET /api/dashboard/recent-registrations` - Get recent gadget registrations
- `GET /api/dashboard/gadgets-by-category` - Get gadgets grouped by category
- `GET /api/dashboard/incidents-by-type` - Get incidents grouped by type
- `GET /api/dashboard/expiring-registrations` - Get gadgets expiring within 30 days

## Database Schema

### Main Tables
1. **STUDENT** - Student information and details
2. **GADGET_REGISTRATION** - Registered devices
3. **GADGET_CATEGORY** - Device categories (Laptop, Smartphone, etc.)
4. **INCIDENT_REPORT** - Incident records
5. **DEPARTMENT** - Department information
6. **PAYMENT** - Payment records
7. **WARRANTY** - Warranty information
8. **INSURANCE_POLICY** - Insurance policies

## Features Details

### Dashboard
- Display key statistics (total students, gadgets, incidents, expiring devices)
- Show recent gadget registrations
- List gadgets expiring within 30 days
- Visualize gadgets by category
- Show incidents by type

### Student Management
- Add/edit/delete student records
- View all students with filtering by department
- Track emergency contact information
- Monitor student enrollment status

### Gadget Registration
- Register new devices with detailed information
- Track device serial numbers and IMEI numbers
- Monitor device condition and warranty
- Manage insurance policies
- Track purchase information

### Incident Reporting
- Report lost, stolen, or damaged devices
- Link incidents to specific gadgets and students
- Track incident resolution status
- Maintain police report numbers for legal incidents

## Styling

The application uses a modern, responsive design with:
- CSS custom properties (variables) for consistent theming
- Mobile-responsive layout
- Color-coded status badges
- Professional card-based layouts
- Smooth transitions and animations
- Dark-aware color scheme

## Technologies Used

- **Backend**: Node.js, Express.js
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Database**: MySQL with mysql2 driver
- **Architecture**: RESTful API

## Error Handling

The application includes comprehensive error handling:
- Database connection error messages
- Validation of required fields
- HTTP status code responses
- User-friendly alert messages

## Notes

- The database credentials are left blank for manual configuration
- Ensure MySQL is running before starting the server
- The application uses localhost:3306 as the default MySQL port
- CORS is enabled for cross-origin requests

## Future Enhancements

- User authentication and authorization
- Email notifications for expiring gadgets
- Export reports to PDF/Excel
- Advanced search and filtering
- Mobile app companion
- SMS alerts
- Device tracking system

## License

ISC

## Support

For issues or questions, please refer to the API endpoints documentation or the inline code comments.
