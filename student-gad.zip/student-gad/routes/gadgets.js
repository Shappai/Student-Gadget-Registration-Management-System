const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all gadget registrations
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.*, s.first_name, s.last_name, s.email, gc.category_name
      FROM GADGET_REGISTRATION gr
      LEFT JOIN STUDENT s ON gr.student_id = s.student_id
      LEFT JOIN GADGET_CATEGORY gc ON gr.category_id = gc.category_id
      ORDER BY gr.registration_date DESC
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get gadget by registration ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.*, s.first_name, s.last_name, s.email, gc.category_name
      FROM GADGET_REGISTRATION gr
      LEFT JOIN STUDENT s ON gr.student_id = s.student_id
      LEFT JOIN GADGET_CATEGORY gc ON gr.category_id = gc.category_id
      WHERE gr.registration_id = ?
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Gadget registration not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new gadget registration
router.post('/', async (req, res) => {
  try {
    const {
      registration_id,
      student_id,
      category_id,
      device_name,
      brand,
      model,
      serial_number,
      imei_number,
      purchase_date,
      purchase_price,
      color,
      condition,
      registration_date,
      expiry_date,
      status,
      payment_id
    } = req.body;

    if (!registration_id || !student_id || !category_id || !device_name) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    await db.query(`
  INSERT INTO \`GADGET_REGISTRATION\` 
  (\`registration_id\`, \`student_id\`, \`category_id\`, \`device_name\`, \`brand\`, \`model\`, \`serial_number\`, 
   \`imei_number\`, \`purchase_date\`, \`purchase_price\`, \`color\`, \`condition\`, \`registration_date\`, 
   \`expiry_date\`, \`status\`, \`payment_id\`)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [registration_id, student_id, category_id, device_name, brand, model, serial_number, 
        imei_number, purchase_date, purchase_price, color, condition, registration_date, 
        expiry_date, status || 'Active', payment_id]);
    
    res.status(201).json({ message: 'Gadget registered successfully', registration_id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update gadget registration
router.put('/:id', async (req, res) => {
  try {
    const {
      student_id,
      category_id,
      device_name,
      brand,
      model,
      serial_number,
      imei_number,
      purchase_date,
      purchase_price,
      color,
      condition,
      expiry_date,
      status,
      payment_id
    } = req.body;

    const [result] = await db.query(`
    UPDATE \`GADGET_REGISTRATION\` 
    SET \`student_id\` = ?, \`category_id\` = ?, \`device_name\` = ?, \`brand\` = ?, \`model\` = ?, 
      \`serial_number\` = ?, \`imei_number\` = ?, \`purchase_date\` = ?, \`purchase_price\` = ?, 
      \`color\` = ?, \`condition\` = ?, \`expiry_date\` = ?, \`status\` = ?, \`payment_id\` = ?
    WHERE \`registration_id\` = ?
    `, [student_id, category_id, device_name, brand, model, serial_number, imei_number, 
        purchase_date, purchase_price, color, condition, expiry_date, status, payment_id, req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Gadget registration not found' });
    }
    res.json({ message: 'Gadget updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete gadget registration
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM GADGET_REGISTRATION WHERE registration_id = ?',
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Gadget registration not found' });
    }
    res.json({ message: 'Gadget deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get gadgets by student ID
router.get('/student/:student_id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.*, gc.category_name
      FROM GADGET_REGISTRATION gr
      LEFT JOIN GADGET_CATEGORY gc ON gr.category_id = gc.category_id
      WHERE gr.student_id = ?
      ORDER BY gr.registration_date DESC
    `, [req.params.student_id]);
    
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get gadgets by category
router.get('/category/:category_id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.*, s.first_name, s.last_name, gc.category_name
      FROM GADGET_REGISTRATION gr
      LEFT JOIN STUDENT s ON gr.student_id = s.student_id
      LEFT JOIN GADGET_CATEGORY gc ON gr.category_id = gc.category_id
      WHERE gr.category_id = ?
      ORDER BY gr.registration_date DESC
    `, [req.params.category_id]);
    
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all gadget categories
router.get('/categories/all', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM GADGET_CATEGORY ORDER BY category_name'
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
