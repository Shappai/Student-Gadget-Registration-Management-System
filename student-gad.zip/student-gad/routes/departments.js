const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all departments
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM DEPARTMENT ORDER BY department_name'
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get department by code
router.get('/:code', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM DEPARTMENT WHERE department_code = ?',
      [req.params.code]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Department not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new department
router.post('/', async (req, res) => {
  try {
    const {
      department_code,
      department_name,
      faculty,
      hod_name,
      contact_email
    } = req.body;

    if (!department_code || !department_name) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    await db.query(`
      INSERT INTO DEPARTMENT 
      (department_code, department_name, faculty, hod_name, contact_email)
      VALUES (?, ?, ?, ?, ?)
    `, [department_code, department_name, faculty, hod_name, contact_email]);
    
    res.status(201).json({ 
      message: 'Department created successfully', 
      department_code 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update department
router.put('/:code', async (req, res) => {
  try {
    const {
      department_name,
      faculty,
      hod_name,
      contact_email
    } = req.body;

    const [result] = await db.query(`
      UPDATE DEPARTMENT 
      SET department_name = ?, faculty = ?, hod_name = ?, contact_email = ?
      WHERE department_code = ?
    `, [department_name, faculty, hod_name, contact_email, req.params.code]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Department not found' });
    }
    res.json({ message: 'Department updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete department
router.delete('/:code', async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM DEPARTMENT WHERE department_code = ?',
      [req.params.code]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Department not found' });
    }
    res.json({ message: 'Department deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get students in a department
router.get('/:code/students', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM STUDENT WHERE department_code = ? ORDER BY first_name',
      [req.params.code]
    );
    
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get department statistics
router.get('/:code/stats', async (req, res) => {
  try {
    const [result] = await db.query(`
      SELECT 
        d.department_code,
        d.department_name,
        COUNT(DISTINCT s.student_id) as total_students,
        COUNT(DISTINCT gr.registration_id) as total_gadgets,
        COUNT(DISTINCT CASE WHEN ir.status != 'Resolved' THEN ir.incident_id END) as open_incidents
      FROM DEPARTMENT d
      LEFT JOIN STUDENT s ON d.department_code = s.department_code
      LEFT JOIN GADGET_REGISTRATION gr ON s.student_id = gr.student_id
      LEFT JOIN INCIDENT_REPORT ir ON s.student_id = ir.student_id
      WHERE d.department_code = ?
      GROUP BY d.department_code, d.department_name
    `, [req.params.code]);
    
    if (result.length === 0) {
      return res.status(404).json({ error: 'Department not found' });
    }
    res.json(result[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
