const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get dashboard statistics
router.get('/stats', async (req, res) => {
  try {
    // Total students
    const [studentCount] = await db.query(
      'SELECT COUNT(*) as total FROM STUDENT WHERE status = "Active"'
    );

    // Total registered gadgets
    const [gadgetCount] = await db.query(
      'SELECT COUNT(*) as total FROM GADGET_REGISTRATION WHERE status = "Active"'
    );

    // Total incidents
    const [incidentCount] = await db.query(
      'SELECT COUNT(*) as total FROM INCIDENT_REPORT WHERE status != "Resolved"'
    );

    // Total departments
    const [deptCount] = await db.query(
      'SELECT COUNT(*) as total FROM DEPARTMENT'
    );

    // Expiring registrations (within 30 days)
    const [expiringCount] = await db.query(`
      SELECT COUNT(*) as total 
      FROM GADGET_REGISTRATION 
      WHERE status = 'Active' 
      AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    `);

    res.json({
      students: studentCount[0].total,
      gadgets: gadgetCount[0].total,
      incidents: incidentCount[0].total,
      departments: deptCount[0].total,
      expiring: expiringCount[0].total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get recent registrations
router.get('/recent-registrations', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.registration_id, gr.device_name, gr.brand, gr.registration_date,
             CONCAT(s.first_name, ' ', s.last_name) as student_name,
             gc.category_name
      FROM GADGET_REGISTRATION gr
      LEFT JOIN STUDENT s ON gr.student_id = s.student_id
      LEFT JOIN GADGET_CATEGORY gc ON gr.category_id = gc.category_id
      ORDER BY gr.registration_date DESC
      LIMIT 5
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get gadgets by category
router.get('/gadgets-by-category', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gc.category_name, COUNT(gr.registration_id) as count
      FROM GADGET_CATEGORY gc
      LEFT JOIN GADGET_REGISTRATION gr ON gc.category_id = gr.category_id 
        AND gr.status = 'Active'
      GROUP BY gc.category_id, gc.category_name
      ORDER BY count DESC
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get incidents by type
router.get('/incidents-by-type', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT incident_type, COUNT(*) as count
      FROM INCIDENT_REPORT
      GROUP BY incident_type
      ORDER BY count DESC
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get expiring registrations
router.get('/expiring-registrations', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT gr.registration_id, gr.device_name, gr.expiry_date,
             CONCAT(s.first_name, ' ', s.last_name) as student_name,
             s.email,
             DATEDIFF(gr.expiry_date, CURDATE()) as days_remaining
      FROM GADGET_REGISTRATION gr
      LEFT JOIN STUDENT s ON gr.student_id = s.student_id
      WHERE gr.status = 'Active'
      AND gr.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
      ORDER BY gr.expiry_date ASC
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;