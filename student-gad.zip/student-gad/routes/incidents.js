const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all incident reports
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ir.*, s.first_name, s.last_name, s.email, gr.device_name, gr.brand
      FROM INCIDENT_REPORT ir
      LEFT JOIN STUDENT s ON ir.student_id = s.student_id
      LEFT JOIN GADGET_REGISTRATION gr ON ir.registration_id = gr.registration_id
      ORDER BY ir.incident_date DESC
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get incident by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ir.*, s.first_name, s.last_name, s.email, gr.device_name, gr.brand
      FROM INCIDENT_REPORT ir
      LEFT JOIN STUDENT s ON ir.student_id = s.student_id
      LEFT JOIN GADGET_REGISTRATION gr ON ir.registration_id = gr.registration_id
      WHERE ir.incident_id = ?
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Incident not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new incident report
router.post('/', async (req, res) => {
  try {
    const {
      registration_id,
      student_id,
      incident_date,
      incident_type,
      description,
      location,
      police_report_number,
      status,
      resolution_date
    } = req.body;

    if (!registration_id || !student_id || !incident_date || !incident_type) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const [result] = await db.query(`
      INSERT INTO INCIDENT_REPORT 
      (registration_id, student_id, incident_date, incident_type, description, 
       location, police_report_number, status, resolution_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [registration_id, student_id, incident_date, incident_type, description, 
        location, police_report_number, status || 'Pending', resolution_date]);
    
    res.status(201).json({ 
      message: 'Incident report created successfully', 
      incident_id: result.insertId 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update incident report
router.put('/:id', async (req, res) => {
  try {
    const {
      registration_id,
      student_id,
      incident_date,
      incident_type,
      description,
      location,
      police_report_number,
      status,
      resolution_date
    } = req.body;

    const [result] = await db.query(`
      UPDATE INCIDENT_REPORT 
      SET registration_id = ?, student_id = ?, incident_date = ?, incident_type = ?, 
          description = ?, location = ?, police_report_number = ?, status = ?, resolution_date = ?
      WHERE incident_id = ?
    `, [registration_id, student_id, incident_date, incident_type, description, 
        location, police_report_number, status, resolution_date, req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Incident not found' });
    }
    res.json({ message: 'Incident updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete incident report
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM INCIDENT_REPORT WHERE incident_id = ?',
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Incident not found' });
    }
    res.json({ message: 'Incident deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get incidents by student ID
router.get('/student/:student_id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ir.*, gr.device_name, gr.brand
      FROM INCIDENT_REPORT ir
      LEFT JOIN GADGET_REGISTRATION gr ON ir.registration_id = gr.registration_id
      WHERE ir.student_id = ?
      ORDER BY ir.incident_date DESC
    `, [req.params.student_id]);
    
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get incidents by status
router.get('/status/:status', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ir.*, s.first_name, s.last_name, gr.device_name
      FROM INCIDENT_REPORT ir
      LEFT JOIN STUDENT s ON ir.student_id = s.student_id
      LEFT JOIN GADGET_REGISTRATION gr ON ir.registration_id = gr.registration_id
      WHERE ir.status = ?
      ORDER BY ir.incident_date DESC
    `, [req.params.status]);
    
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get incident statistics
router.get('/stats/all', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        COUNT(*) as total_incidents,
        SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'Under Investigation' THEN 1 ELSE 0 END) as under_investigation
      FROM INCIDENT_REPORT
    `);
    
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
