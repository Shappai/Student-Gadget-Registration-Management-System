const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all students
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM STUDENT ORDER BY student_id'
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get student by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM STUDENT WHERE student_id = ?',
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new student
router.post('/', async (req, res) => {
  try {
    const {
      student_id,
      first_name,
      last_name,
      email,
      phone_number,
      department_code,
      level,
      enrollment_date,
      status,
      emergency_contact,
      emergency_phone
    } = req.body;

    if (!student_id || !first_name || !last_name || !email) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    await db.query(
      'INSERT INTO STUDENT (student_id, first_name, last_name, email, phone_number, department_code, level, enrollment_date, status, emergency_contact, emergency_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [student_id, first_name, last_name, email, phone_number, department_code, level, enrollment_date, status || 'Active', emergency_contact, emergency_phone]
    );
    res.status(201).json({ message: 'Student created successfully', student_id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update student
router.put('/:id', async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      phone_number,
      department_code,
      level,
      status,
      emergency_contact,
      emergency_phone
    } = req.body;

    const [result] = await db.query(
      'UPDATE STUDENT SET first_name = ?, last_name = ?, email = ?, phone_number = ?, department_code = ?, level = ?, status = ?, emergency_contact = ?, emergency_phone = ? WHERE student_id = ?',
      [first_name, last_name, email, phone_number, department_code, level, status, emergency_contact, emergency_phone, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json({ message: 'Student updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete student
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM STUDENT WHERE student_id = ?',
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json({ message: 'Student deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get students by department
router.get('/department/:dept_code', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM STUDENT WHERE department_code = ? ORDER BY first_name',
      [req.params.dept_code]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
