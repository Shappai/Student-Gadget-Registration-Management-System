(async () => {
  // Simple DB connectivity test using the existing config
  try {
    const pool = require('../config/database');
    console.log('Testing DB connection...');
    const [result] = await pool.query('SELECT NOW() AS now');
    console.log('Connection OK, server time:', result[0].now);

    // Try a simple table query if STUDENT exists
    try {
      const [rows] = await pool.query('SELECT COUNT(*) AS cnt FROM STUDENT');
      console.log('STUDENT table exists, row count:', rows[0].cnt);
    } catch (innerErr) {
      console.warn('Could not query STUDENT table (it may not exist):', innerErr.message);
    }

    // close pool
    await pool.end();
    process.exit(0);
  } catch (err) {
    console.error('DB connection test failed:');
    console.error(err);
    process.exit(1);
  }
})();
