student-gadget-system/
│
├── config/
│   └── database.js
│
├── routes/
│   ├── students.js
│   ├── gadgets.js
│   ├── departments.js
│   ├── incidents.js
│   └── dashboard.js
│
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── main.js
│   │   ├── students.js
│   │   ├── gadgets.js
│   │   ├── incidents.js
│   │   └── dashboard.js
│   ├── index.html
│   ├── students.html
│   ├── gadgets.html
│   ├── incidents.html
│   └── dashboard.html
│
├── .env
├── .gitignore
├── package.json
├── server.js
└── README.md