// main.js - Home page statistics

const API_URL = 'http://localhost:3000/api';

async function loadStatistics() {
  try {
    // Load dashboard stats
    const statsResponse = await fetch(`${API_URL}/dashboard/stats`);
    const stats = await statsResponse.json();

    const totalStudentsEl = document.getElementById('totalStudents');
    const totalGadgetsEl = document.getElementById('totalGadgets');
    const totalIncidentsEl = document.getElementById('totalIncidents');
    const expiringGadgetsEl = document.getElementById('expiringGadgets');

    if (totalStudentsEl) totalStudentsEl.textContent = stats.students || 0;
    if (totalGadgetsEl) totalGadgetsEl.textContent = stats.gadgets || 0;
    if (totalIncidentsEl) totalIncidentsEl.textContent = stats.incidents || 0;
    if (expiringGadgetsEl) expiringGadgetsEl.textContent = stats.expiring || 0;
  } catch (error) {
    console.error('Error loading statistics:', error);
  }
}

// Load statistics when page loads
document.addEventListener('DOMContentLoaded', () => {
  loadStatistics();
});