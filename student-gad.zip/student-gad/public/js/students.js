// students.js - Student management functionality

const API_URL = 'http://localhost:3000/api';
let currentEditingStudentId = null;

async function loadStudents() {
  try {
    const response = await fetch(`${API_URL}/students`);
    const students = await response.json();
    displayStudents(students);
  } catch (error) {
    console.error('Error loading students:', error);
  }
}

function displayStudents(students) {
  const studentsList = document.getElementById('studentsList');
  
  if (!students || students.length === 0) {
    studentsList.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 2rem;">No students found</td></tr>';
    return;
  }

  studentsList.innerHTML = students.map(student => `
    <tr>
      <td>${student.student_id}</td>
      <td>${student.first_name} ${student.last_name}</td>
      <td>${student.email}</td>
      <td>${student.department_code || '-'}</td>
      <td>${student.level || '-'}</td>
      <td><span class="badge ${student.status === 'Active' ? 'badge-success' : 'badge-danger'}">${student.status}</span></td>
      <td>
        <div class="actions">
          <button class="btn btn-sm btn-primary" onclick="openEditStudentModal('${student.student_id}')">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteStudent('${student.student_id}')">Delete</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function openAddStudentModal() {
  currentEditingStudentId = null;
  document.getElementById('modalTitle').textContent = 'Add New Student';
  document.getElementById('studentForm').reset();
  document.getElementById('student_id').disabled = false;
  document.getElementById('studentModal').classList.add('active');
}

async function openEditStudentModal(studentId) {
  try {
    const response = await fetch(`${API_URL}/students/${studentId}`);
    const student = await response.json();
    
    currentEditingStudentId = studentId;
    document.getElementById('modalTitle').textContent = 'Edit Student';
    document.getElementById('student_id').value = student.student_id;
    document.getElementById('first_name').value = student.first_name;
    document.getElementById('last_name').value = student.last_name;
    document.getElementById('email').value = student.email;
    document.getElementById('phone_number').value = student.phone_number || '';
    document.getElementById('department_code').value = student.department_code || '';
    document.getElementById('level').value = student.level || '';
    document.getElementById('enrollment_date').value = student.enrollment_date || '';
    document.getElementById('emergency_contact').value = student.emergency_contact || '';
    document.getElementById('emergency_phone').value = student.emergency_phone || '';
    document.getElementById('status').value = student.status;
    document.getElementById('student_id').disabled = true;
    
    document.getElementById('studentModal').classList.add('active');
  } catch (error) {
    console.error('Error loading student:', error);
    alert('Failed to load student details');
  }
}

function closeStudentModal() {
  document.getElementById('studentModal').classList.remove('active');
  document.getElementById('studentForm').reset();
}

async function handleStudentSubmit(event) {
  event.preventDefault();

  const studentData = {
    student_id: document.getElementById('student_id').value,
    first_name: document.getElementById('first_name').value,
    last_name: document.getElementById('last_name').value,
    email: document.getElementById('email').value,
    phone_number: document.getElementById('phone_number').value,
    department_code: document.getElementById('department_code').value,
    level: document.getElementById('level').value,
    enrollment_date: document.getElementById('enrollment_date').value,
    emergency_contact: document.getElementById('emergency_contact').value,
    emergency_phone: document.getElementById('emergency_phone').value,
    status: document.getElementById('status').value
  };

  try {
    if (currentEditingStudentId) {
      // Update existing student
      const response = await fetch(`${API_URL}/students/${currentEditingStudentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentData)
      });
      
      if (!response.ok) throw new Error('Failed to update student');
      alert('Student updated successfully');
    } else {
      // Create new student
      const response = await fetch(`${API_URL}/students`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentData)
      });
      
      if (!response.ok) throw new Error('Failed to create student');
      alert('Student created successfully');
    }

    closeStudentModal();
    loadStudents();
  } catch (error) {
    console.error('Error saving student:', error);
    alert('Failed to save student: ' + error.message);
  }
}

async function deleteStudent(studentId) {
  if (!confirm('Are you sure you want to delete this student?')) return;

  try {
    const response = await fetch(`${API_URL}/students/${studentId}`, {
      method: 'DELETE'
    });

    if (!response.ok) throw new Error('Failed to delete student');
    alert('Student deleted successfully');
    loadStudents();
  } catch (error) {
    console.error('Error deleting student:', error);
    alert('Failed to delete student: ' + error.message);
  }
}

// Load students on page load
document.addEventListener('DOMContentLoaded', () => {
  loadStudents();

  // Close modal when clicking outside
  document.getElementById('studentModal').addEventListener('click', (e) => {
    if (e.target.id === 'studentModal') {
      closeStudentModal();
    }
  });
});
