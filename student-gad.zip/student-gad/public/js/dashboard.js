// dashboard.js - Dashboard statistics and charts

const API_URL = 'http://localhost:3000/api';

async function loadDashboardStats() {
  try {
    const response = await fetch(`${API_URL}/dashboard/stats`);
    const stats = await response.json();

    document.getElementById('totalStudents').textContent = stats.students || 0;
    document.getElementById('totalGadgets').textContent = stats.gadgets || 0;
    document.getElementById('totalIncidents').textContent = stats.incidents || 0;
    document.getElementById('expiringGadgets').textContent = stats.expiring || 0;
  } catch (error) {
    console.error('Error loading dashboard stats:', error);
  }
}

async function loadRecentRegistrations() {
  try {
    const response = await fetch(`${API_URL}/dashboard/recent-registrations`);
    const registrations = await response.json();
    
    const tbody = document.getElementById('recentRegsList');
    if (!registrations || registrations.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">No recent registrations</td></tr>';
      return;
    }

    tbody.innerHTML = registrations.map(reg => `
      <tr>
        <td>${reg.registration_id}</td>
        <td>${reg.device_name}</td>
        <td>${reg.student_name || '-'}</td>
        <td>${reg.category_name || '-'}</td>
        <td>${new Date(reg.registration_date).toLocaleDateString()}</td>
      </tr>
    `).join('');
  } catch (error) {
    console.error('Error loading recent registrations:', error);
  }
}

async function loadExpiringRegistrations() {
  try {
    const response = await fetch(`${API_URL}/dashboard/expiring-registrations`);
    const registrations = await response.json();
    
    const tbody = document.getElementById('expiringRegsList');
    if (!registrations || registrations.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">No expiring gadgets</td></tr>';
      return;
    }

    tbody.innerHTML = registrations.map(reg => `
      <tr>
        <td>${reg.registration_id}</td>
        <td>${reg.device_name}</td>
        <td>${reg.student_name || '-'}</td>
        <td>${new Date(reg.expiry_date).toLocaleDateString()}</td>
        <td><span class="badge badge-warning">${reg.days_remaining} days</span></td>
      </tr>
    `).join('');
  } catch (error) {
    console.error('Error loading expiring registrations:', error);
  }
}

async function loadGadgetsByCategory() {
  try {
    const response = await fetch(`${API_URL}/dashboard/gadgets-by-category`);
    const data = await response.json();
    
    const tbody = document.getElementById('categoryList');
    if (!data || data.length === 0) {
      tbody.innerHTML = '<tr><td colspan="2" style="text-align:center">No category data</td></tr>';
      return;
    }

    tbody.innerHTML = data.map(item => `
      <tr>
        <td>${item.category_name || '-'}</td>
        <td>${item.count}</td>
      </tr>
    `).join('');
  } catch (error) {
    console.error('Error loading gadgets by category:', error);
  }
}

async function loadIncidentsByType() {
  try {
    const response = await fetch(`${API_URL}/dashboard/incidents-by-type`);
    const data = await response.json();
    
    const tbody = document.getElementById('incidentTypeList');
    if (!data || data.length === 0) {
      tbody.innerHTML = '<tr><td colspan="2" style="text-align:center">No incident data</td></tr>';
      return;
    }

    tbody.innerHTML = data.map(item => `
      <tr>
        <td>${item.incident_type}</td>
        <td>${item.count}</td>
      </tr>
    `).join('');
  } catch (error) {
    console.error('Error loading incidents by type:', error);
  }
}

// Load all dashboard data on page load
document.addEventListener('DOMContentLoaded', () => {
  loadDashboardStats();
  loadRecentRegistrations();
  loadExpiringRegistrations();
  loadGadgetsByCategory();
  loadIncidentsByType();

  // Refresh data every 30 seconds
  setInterval(() => {
    loadDashboardStats();
    loadRecentRegistrations();
    loadExpiringRegistrations();
  }, 30000);
});
