// gadgets.js - Gadget registration management functionality

const API_URL = 'http://localhost:3000/api';
let currentEditingGadgetId = null;

// Populate student and category selects for gadget modal
async function loadStudentsForGadgetModal() {
  try {
    const res = await fetch(`${API_URL}/students`);
    const students = await res.json();
    const studentSelect = document.getElementById('student_id');
    if (!studentSelect) return;
    // Clear existing (but keep the placeholder option)
    studentSelect.innerHTML = '<option value="">Select Student</option>' + (students && students.length ? students.map(s => `<option value="${s.student_id}">${s.first_name || ''} ${s.last_name || ''} (${s.student_id})</option>`).join('') : '');
  } catch (err) {
    console.error('Failed to load students for gadget modal', err);
  }
}

async function loadCategoriesForGadgetModal() {
  try {
    const res = await fetch(`${API_URL}/gadgets/categories/all`);
    const cats = await res.json();
    const catSelect = document.getElementById('category_id');
    if (!catSelect) return;
    catSelect.innerHTML = '<option value="">Select Category</option>' + (cats && cats.length ? cats.map(c => `<option value="${c.category_id}">${c.category_name}</option>`).join('') : '');
  } catch (err) {
    console.error('Failed to load categories for gadget modal', err);
  }
}

async function loadGadgets() {
  try {
    const response = await fetch(`${API_URL}/gadgets`);
    const gadgets = await response.json();
    displayGadgets(gadgets);
  } catch (error) {
    console.error('Error loading gadgets:', error);
  }
}

function displayGadgets(gadgets) {
  const gadgetsList = document.getElementById('gadgetsList');
  
  if (!gadgets || gadgets.length === 0) {
    gadgetsList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 2rem;">No gadgets found</td></tr>';
    return;
  }

  gadgetsList.innerHTML = gadgets.map(gadget => `
    <tr>
      <td>${gadget.registration_id}</td>
      <td>${gadget.device_name}</td>
      <td>${gadget.brand || '-'}</td>
      <td>${gadget.first_name ? gadget.first_name + ' ' + gadget.last_name : '-'}</td>
      <td>${gadget.category_name || '-'}</td>
      <td>${new Date(gadget.registration_date).toLocaleDateString()}</td>
      <td><span class="badge ${gadget.status === 'Active' ? 'badge-success' : 'badge-danger'}">${gadget.status}</span></td>
      <td>
        <div class="actions">
          <button class="btn btn-sm btn-primary" onclick="openEditGadgetModal('${gadget.registration_id}')">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteGadget('${gadget.registration_id}')">Delete</button>
        </div>
      </td>
    </tr>
  `).join('');
}

async function openAddGadgetModal() {
  currentEditingGadgetId = null;
  document.getElementById('modalTitle').textContent = 'Register New Gadget';
  document.getElementById('gadgetForm').reset();
  document.getElementById('registration_id').disabled = false;
  // populate selects before showing
  await Promise.all([loadStudentsForGadgetModal(), loadCategoriesForGadgetModal()]);
  document.getElementById('gadgetModal').classList.add('active');
}

async function openEditGadgetModal(registrationId) {
  try {
    // ensure selects are populated first so we can set values
    await Promise.all([loadStudentsForGadgetModal(), loadCategoriesForGadgetModal()]);
    const response = await fetch(`${API_URL}/gadgets/${registrationId}`);
    const gadget = await response.json();
    
    currentEditingGadgetId = registrationId;
    document.getElementById('modalTitle').textContent = 'Edit Gadget Registration';
    document.getElementById('registration_id').value = gadget.registration_id;
    document.getElementById('student_id').value = gadget.student_id;
    document.getElementById('category_id').value = gadget.category_id;
    document.getElementById('device_name').value = gadget.device_name;
    document.getElementById('brand').value = gadget.brand || '';
    document.getElementById('model').value = gadget.model || '';
    document.getElementById('serial_number').value = gadget.serial_number || '';
    document.getElementById('imei_number').value = gadget.imei_number || '';
    document.getElementById('purchase_date').value = gadget.purchase_date || '';
    document.getElementById('purchase_price').value = gadget.purchase_price || '';
    document.getElementById('color').value = gadget.color || '';
    document.getElementById('condition').value = gadget.condition || '';
    document.getElementById('registration_date').value = gadget.registration_date;
    document.getElementById('expiry_date').value = gadget.expiry_date || '';
    document.getElementById('status').value = gadget.status;
    document.getElementById('registration_id').disabled = true;
    
    document.getElementById('gadgetModal').classList.add('active');
  } catch (error) {
    console.error('Error loading gadget:', error);
    alert('Failed to load gadget details');
  }
}

function closeGadgetModal() {
  document.getElementById('gadgetModal').classList.remove('active');
  document.getElementById('gadgetForm').reset();
}

async function handleGadgetSubmit(event) {
  event.preventDefault();

  // gather and validate inputs
  const registration_id = document.getElementById('registration_id').value.trim();
  const student_id = document.getElementById('student_id').value;
  const categoryVal = document.getElementById('category_id').value;
  const category_id = categoryVal ? parseInt(categoryVal, 10) : null;
  const device_name = document.getElementById('device_name').value.trim();

  // Client-side validation for required fields to give immediate feedback
  if (!registration_id) return alert('Registration ID is required');
  if (!student_id) return alert('Please select a student');
  if (!category_id) return alert('Please select a category');
  if (!device_name) return alert('Device name is required');

  const gadgetData = {
    registration_id,
    student_id,
    category_id,
    device_name,
    brand: document.getElementById('brand').value,
    model: document.getElementById('model').value,
    serial_number: document.getElementById('serial_number').value,
    imei_number: document.getElementById('imei_number').value,
    purchase_date: document.getElementById('purchase_date').value || null,
    purchase_price: document.getElementById('purchase_price').value || null,
    color: document.getElementById('color').value,
    condition: document.getElementById('condition').value,
    registration_date: document.getElementById('registration_date').value,
    expiry_date: document.getElementById('expiry_date').value || null,
    status: document.getElementById('status').value
  };

  try {
    if (currentEditingGadgetId) {
      // Update existing gadget
      const response = await fetch(`${API_URL}/gadgets/${currentEditingGadgetId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gadgetData)
      });
      
      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        throw new Error(errBody.error || 'Failed to update gadget');
      }
      alert('Gadget updated successfully');
    } else {
      // Create new gadget
      const response = await fetch(`${API_URL}/gadgets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gadgetData)
      });
      
      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        throw new Error(errBody.error || 'Failed to register gadget');
      }
      alert('Gadget registered successfully');
    }

    closeGadgetModal();
    loadGadgets();
  } catch (error) {
    console.error('Error saving gadget:', error);
    alert('Failed to save gadget: ' + error.message);
  }
}

async function deleteGadget(registrationId) {
  if (!confirm('Are you sure you want to delete this gadget registration?')) return;

  try {
    const response = await fetch(`${API_URL}/gadgets/${registrationId}`, {
      method: 'DELETE'
    });

    if (!response.ok) throw new Error('Failed to delete gadget');
    alert('Gadget deleted successfully');
    loadGadgets();
  } catch (error) {
    console.error('Error deleting gadget:', error);
    alert('Failed to delete gadget: ' + error.message);
  }
}

// Load gadgets on page load
document.addEventListener('DOMContentLoaded', () => {
  // Load lists and helpers
  loadGadgets();
  loadStudentsForGadgetModal();
  loadCategoriesForGadgetModal();

  // Close modal when clicking outside
  document.getElementById('gadgetModal').addEventListener('click', (e) => {
    if (e.target.id === 'gadgetModal') {
      closeGadgetModal();
    }
  });
});
