// incidents.js - Incident report management
const API_URL = "http://localhost:3000/api";
let currentEditingIncidentId = null;

async function loadIncidents() {
  try {
    const response = await fetch(API_URL + "/incidents");
    const incidents = await response.json();
    displayIncidents(incidents);
  } catch (error) {
    console.error("Error loading incidents:", error);
  }
}

function displayIncidents(incidents) {
  const tbody = document.getElementById("incidentsTable");
  if (!incidents || incidents.length === 0) {
    tbody.innerHTML = "<tr><td colspan='8' style='text-align:center;padding:2rem'>No incidents found</td></tr>";
    return;
  }
  tbody.innerHTML = incidents.map(i => 
    "<tr><td>" + i.incident_id + "</td><td>" + (i.first_name ? i.first_name + " " + i.last_name : "-") + 
    "</td><td>" + (i.device_name || "-") + "</td><td>" + i.incident_type + 
    "</td><td>" + new Date(i.incident_date).toLocaleDateString() +
    "</td><td>" + (i.location || "-") + "</td><td>" +
    "<span class='badge badge-" + (i.status === "Resolved" ? "success" : "warning") + "'>" + i.status + "</span>" +
    "</td><td><div class='actions'>" +
    "<button class='btn btn-sm btn-primary' onclick='editIncident(" + i.incident_id + ")'>Edit</button>" +
    "<button class='btn btn-sm btn-danger' onclick='deleteIncident(" + i.incident_id + ")'>Delete</button>" +
    "</div></td></tr>"
  ).join("");
}

async function loadStudentsForModal() {
  try {
    const response = await fetch(API_URL + "/students");
    const students = await response.json();
    const select = document.getElementById("student_id");
    select.innerHTML = "<option value=''>Select Student</option>";
    students.filter(s => s.status === "Active").forEach(student => {
      const opt = document.createElement("option");
      opt.value = student.student_id;
      opt.text = student.first_name + " " + student.last_name + " (" + student.student_id + ")";
      select.appendChild(opt);
    });
  } catch (error) {
    console.error("Error loading students:", error);
  }
}

async function loadStudentGadgets() {
  const studentId = document.getElementById("student_id").value;
  const select = document.getElementById("registration_id");
  if (!studentId) {
    select.innerHTML = "<option value=''>Select Gadget</option>";
    return;
  }
  try {
    const response = await fetch(API_URL + "/gadgets/student/" + studentId);
    const gadgets = await response.json();
    select.innerHTML = "<option value=''>Select Gadget</option>";
    gadgets.filter(g => g.status === "Active").forEach(gadget => {
      const opt = document.createElement("option");
      opt.value = gadget.registration_id;
      opt.text = gadget.device_name + " " + gadget.brand + " (" + gadget.registration_id + ")";
      select.appendChild(opt);
    });
  } catch (error) {
    console.error("Error loading gadgets:", error);
  }
}

function openIncidentModal() {
  currentEditingIncidentId = null;
  document.getElementById("modalTitle").textContent = "Report New Incident";
  document.getElementById("incidentForm").reset();
  loadStudentsForModal();
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("incident_date").value = today;
  document.getElementById("status").value = "Pending";
  document.getElementById("incidentModal").classList.add("active");
}

function closeIncidentModal() {
  document.getElementById("incidentModal").classList.remove("active");
}

async function editIncident(id) {
  try {
    const response = await fetch(API_URL + "/incidents/" + id);
    const incident = await response.json();
    currentEditingIncidentId = id;
    document.getElementById("modalTitle").textContent = "Edit Incident Report";
    loadStudentsForModal();
    document.getElementById("incident_id").value = incident.incident_id;
    document.getElementById("student_id").value = incident.student_id;
    document.getElementById("incident_date").value = incident.incident_date ? incident.incident_date.split("T")[0] : "";
    document.getElementById("incident_type").value = incident.incident_type;
    document.getElementById("location").value = incident.location || "";
    document.getElementById("description").value = incident.description || "";
    document.getElementById("police_report_number").value = incident.police_report_number || "";
    document.getElementById("status").value = incident.status;
    document.getElementById("resolution_date").value = incident.resolution_date ? incident.resolution_date.split("T")[0] : "";
    await loadStudentGadgets();
    document.getElementById("registration_id").value = incident.registration_id;
    document.getElementById("incidentModal").classList.add("active");
  } catch (error) {
    alert("Failed to load incident: " + error.message);
  }
}

async function deleteIncident(id) {
  if (!confirm("Delete this incident?")) return;
  try {
    await fetch(API_URL + "/incidents/" + id, { method: "DELETE" });
    alert("Incident deleted");
    loadIncidents();
  } catch (error) {
    alert("Failed to delete: " + error.message);
  }
}

document.addEventListener("DOMContentLoaded", function() {
  loadIncidents();
  document.getElementById("incidentForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const data = {
      registration_id: document.getElementById("registration_id").value,
      student_id: document.getElementById("student_id").value,
      incident_date: document.getElementById("incident_date").value,
      incident_type: document.getElementById("incident_type").value,
      description: document.getElementById("description").value,
      location: document.getElementById("location").value,
      police_report_number: document.getElementById("police_report_number").value,
      status: document.getElementById("status").value,
      resolution_date: document.getElementById("resolution_date").value
    };
    try {
      const method = currentEditingIncidentId ? "PUT" : "POST";
      const url = currentEditingIncidentId ? API_URL + "/incidents/" + currentEditingIncidentId : API_URL + "/incidents";
      const response = await fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (response.ok) {
        alert(currentEditingIncidentId ? "Incident updated" : "Incident created");
        closeIncidentModal();
        loadIncidents();
      }
    } catch (error) {
      alert("Error: " + error.message);
    }
  });
  document.getElementById("incidentModal").addEventListener("click", function(e) {
    if (e.target.id === "incidentModal") closeIncidentModal();
  });
});
