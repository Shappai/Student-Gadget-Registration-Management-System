from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta
from app.database import get_db
from app import models

router = APIRouter()


# ============================================
# DASHBOARD
# ============================================

@router.get("/api/dashboard")
def get_dashboard(db: Session = Depends(get_db)):
    """Get dashboard statistics"""
    stats = {
        "total_students": db.query(models.Student).filter(models.Student.status == "Active").count(),
        "total_registrations": db.query(models.GadgetRegistration).count(),
        "active_registrations": db.query(models.GadgetRegistration).filter(models.GadgetRegistration.status == "Active").count(),
        "pending_incidents": db.query(models.IncidentReport).filter(models.IncidentReport.status == "Pending").count()
    }
    return stats


# ============================================
# STUDENTS
# ============================================

@router.get("/api/students")
def get_students(db: Session = Depends(get_db)):
    """Get all students"""
    students = db.query(models.Student).all()
    return students


@router.get("/api/students/{student_id}")
def get_student(student_id: str, db: Session = Depends(get_db)):
    """Get one student"""
    student = db.query(models.Student).filter(models.Student.student_id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    return student


@router.post("/api/students")
def create_student(student_data: dict, db: Session = Depends(get_db)):
    """Create new student"""
    student = models.Student(**student_data)
    db.add(student)
    db.commit()
    db.refresh(student)
    return student


@router.put("/api/students/{student_id}")
def update_student(student_id: str, student_data: dict, db: Session = Depends(get_db)):
    """Update student"""
    student = db.query(models.Student).filter(models.Student.student_id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    for key, value in student_data.items():
        setattr(student, key, value)
    
    db.commit()
    db.refresh(student)
    return student


@router.delete("/api/students/{student_id}")
def delete_student(student_id: str, db: Session = Depends(get_db)):
    """Delete student"""
    student = db.query(models.Student).filter(models.Student.student_id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    db.delete(student)
    db.commit()
    return {"message": "Student deleted successfully"}


# ============================================
# DEPARTMENTS
# ============================================

@router.get("/api/departments")
def get_departments(db: Session = Depends(get_db)):
    """Get all departments"""
    departments = db.query(models.Department).all()
    return departments


# ============================================
# GADGET CATEGORIES
# ============================================

@router.get("/api/categories")
def get_categories(db: Session = Depends(get_db)):
    """Get all gadget categories"""
    categories = db.query(models.GadgetCategory).all()
    return categories


# ============================================
# REGISTRATIONS
# ============================================

@router.get("/api/registrations")
def get_registrations(db: Session = Depends(get_db)):
    """Get all registrations"""
    registrations = db.query(models.GadgetRegistration).all()
    return registrations


@router.get("/api/registrations/{registration_id}")
def get_registration(registration_id: str, db: Session = Depends(get_db)):
    """Get one registration"""
    registration = db.query(models.GadgetRegistration).filter(
        models.GadgetRegistration.registration_id == registration_id
    ).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")
    return registration


@router.post("/api/registrations")
def create_registration(reg_data: dict, db: Session = Depends(get_db)):
    """Create new registration"""
    # Create payment first
    payment = models.Payment(
        amount=reg_data.get('payment_amount', 5000.00),
        payment_date=datetime.now().date(),
        payment_method=reg_data.get('payment_method', 'Cash'),
        transaction_reference=f"TXN{datetime.now().strftime('%Y%m%d%H%M%S')}",
        status="Completed"
    )
    db.add(payment)
    db.flush()
    
    # Create registration
    registration = models.GadgetRegistration(
        registration_id=f"REG{datetime.now().strftime('%Y%m%d%H%M%S')}",
        student_id=reg_data['student_id'],
        category_id=reg_data['category_id'],
        device_name=reg_data['device_name'],
        brand=reg_data.get('brand'),
        model=reg_data.get('model'),
        serial_number=reg_data.get('serial_number'),
        imei_number=reg_data.get('imei_number'),
        purchase_date=reg_data.get('purchase_date'),
        purchase_price=reg_data.get('purchase_price'),
        color=reg_data.get('color'),
        condition=reg_data.get('condition', 'Excellent'),
        registration_date=datetime.now().date(),
        expiry_date=(datetime.now() + timedelta(days=365)).date(),
        status='Active',
        payment_id=payment.payment_id
    )
    db.add(registration)
    db.commit()
    db.refresh(registration)
    return registration


@router.put("/api/registrations/{registration_id}")
def update_registration(registration_id: str, reg_data: dict, db: Session = Depends(get_db)):
    """Update registration"""
    registration = db.query(models.GadgetRegistration).filter(
        models.GadgetRegistration.registration_id == registration_id
    ).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")
    
    for key, value in reg_data.items():
        setattr(registration, key, value)
    
    db.commit()
    db.refresh(registration)
    return registration


# ============================================
# INCIDENTS
# ============================================

@router.get("/api/incidents")
def get_incidents(db: Session = Depends(get_db)):
    """Get all incidents"""
    incidents = db.query(models.IncidentReport).all()
    return incidents


@router.post("/api/incidents")
def create_incident(incident_data: dict, db: Session = Depends(get_db)):
    """Create new incident"""
    incident = models.IncidentReport(**incident_data)
    db.add(incident)
    db.commit()
    db.refresh(incident)
    return incident


@router.put("/api/incidents/{incident_id}")
def update_incident(incident_id: int, incident_data: dict, db: Session = Depends(get_db)):
    """Update incident"""
    incident = db.query(models.IncidentReport).filter(
        models.IncidentReport.incident_id == incident_id
    ).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    
    for key, value in incident_data.items():
        setattr(incident, key, value)
    
    db.commit()
    db.refresh(incident)
    return incident


# ============================================
# REPORTS
# ============================================

@router.get("/api/reports/expiring")
def get_expiring_registrations(db: Session = Depends(get_db)):
    """Get registrations expiring within 30 days"""
    today = datetime.now().date()
    thirty_days = today + timedelta(days=30)
    
    registrations = db.query(models.GadgetRegistration).filter(
        models.GadgetRegistration.status == 'Active',
        models.GadgetRegistration.expiry_date >= today,
        models.GadgetRegistration.expiry_date <= thirty_days
    ).all()
    
    return registrations


@router.get("/api/reports/departments")
def get_department_stats(db: Session = Depends(get_db)):
    """Get statistics by department"""
    stats = db.query(
        models.Department.department_name,
        models.Department.department_code,
        func.count(models.Student.student_id.distinct()).label('total_students'),
        func.count(models.GadgetRegistration.registration_id).label('total_registrations')
    ).outerjoin(models.Student).outerjoin(models.GadgetRegistration).group_by(
        models.Department.department_code
    ).all()
    
    return [
        {
            "department_name": s[0],
            "department_code": s[1],
            "total_students": s[2],
            "total_registrations": s[3]
        }
        for s in stats
    ]


@router.get("/api/reports/incidents")
def get_incident_summary(db: Session = Depends(get_db)):
    """Get incident summary by type"""
    summary = db.query(
        models.IncidentReport.incident_type,
        func.count(models.IncidentReport.incident_id).label('total'),
        func.sum(func.case((models.IncidentReport.status == 'Pending', 1), else_=0)).label('pending'),
        func.sum(func.case((models.IncidentReport.status == 'Resolved', 1), else_=0)).label('resolved')
    ).group_by(models.IncidentReport.incident_type).all()
    
    return [
        {
            "incident_type": s[0],
            "total": s[1],
            "pending": s[2],
            "resolved": s[3]
        }
        for s in summary
    ]


@router.get("/api/reports/value")
def get_value_summary(db: Session = Depends(get_db)):
    """Get asset value by department"""
    summary = db.query(
        models.Department.department_name,
        func.count(models.GadgetRegistration.registration_id).label('total_gadgets'),
        func.sum(models.GadgetRegistration.purchase_price).label('total_value')
    ).join(models.Student).join(models.GadgetRegistration).filter(
        models.GadgetRegistration.status == 'Active'
    ).group_by(models.Department.department_name).all()
    
    return [
        {
            "department_name": s[0],
            "total_gadgets": s[1],
            "total_value": float(s[2]) if s[2] else 0
        }
        for s in summary
    ]