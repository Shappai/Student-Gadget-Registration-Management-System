from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base
from app import models
from app.routes import router

# Create database tables
Base.metadata.create_all(bind=engine)

# Create FastAPI app
app = FastAPI(
    title="Student Gadget Registration API",
    description="Backend API for Student Gadget Registration System",
    version="1.0.0"
)

# Enable CORS (so frontend can connect)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Include routes
app.include_router(router)

# Root endpoint
@app.get("/")
def root():
    return {
        "message": "Student Gadget Registration API",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "students": "/api/students",
            "registrations": "/api/registrations",
            "incidents": "/api/incidents",
            "reports": "/api/reports/*"
        }
    }

# Health check
@app.get("/health")
def health():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)