from sqlalchemy import Column, String, Integer, Numeric, Date, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base


class Department(Base):
    __tablename__ = "DEPARTMENT"
    
    department_code = Column(String(10), primary_key=True)
    department_name = Column(String(100))
    faculty = Column(String(100))
    hod_name = Column(String(100))
    contact_email = Column(String(100))
    
    students = relationship("Student", back_populates="department")


class Student(Base):
    __tablename__ = "STUDENT"
    
    student_id = Column(String(20), primary_key=True)
    first_name = Column(String(50))
    last_name = Column(String(50))
    email = Column(String(100), unique=True)
    phone_number = Column(String(15))
    department_code = Column(String(10), ForeignKey("DEPARTMENT.department_code"))
    level = Column(String(20))
    enrollment_date = Column(Date)
    status = Column(String(20), default="Active")
    emergency_contact = Column(String(100))
    emergency_phone = Column(String(15))
    
    department = relationship("Department", back_populates="students")
    registrations = relationship("GadgetRegistration", back_populates="student")
    incidents = relationship("IncidentReport", back_populates="student")


class GadgetCategory(Base):
    __tablename__ = "GADGET_CATEGORY"
    
    category_id = Column(Integer, primary_key=True, autoincrement=True)
    category_name = Column(String(50))
    description = Column(Text)
    specifications = Column(Text)
    
    registrations = relationship("GadgetRegistration", back_populates="category")


class Payment(Base):
    __tablename__ = "PAYMENT"
    
    payment_id = Column(Integer, primary_key=True, autoincrement=True)
    amount = Column(Numeric(10, 2))
    payment_date = Column(Date)
    payment_method = Column(String(50))
    transaction_reference = Column(String(100), unique=True)
    status = Column(String(20), default="Completed")
    
    registrations = relationship("GadgetRegistration", back_populates="payment")


class GadgetRegistration(Base):
    __tablename__ = "GADGET_REGISTRATION"
    
    registration_id = Column(String(20), primary_key=True)
    student_id = Column(String(20), ForeignKey("STUDENT.student_id"))
    category_id = Column(Integer, ForeignKey("GADGET_CATEGORY.category_id"))
    device_name = Column(String(100))
    brand = Column(String(50))
    model = Column(String(50))
    serial_number = Column(String(100), unique=True)
    imei_number = Column(String(50))
    purchase_date = Column(Date)
    purchase_price = Column(Numeric(10, 2))
    color = Column(String(30))
    condition = Column(String(50), default="Excellent")
    registration_date = Column(Date)
    expiry_date = Column(Date)
    status = Column(String(20), default="Active")
    payment_id = Column(Integer, ForeignKey("PAYMENT.payment_id"))
    
    student = relationship("Student", back_populates="registrations")
    category = relationship("GadgetCategory", back_populates="registrations")
    payment = relationship("Payment", back_populates="registrations")
    warranty = relationship("Warranty", back_populates="registration", uselist=False)
    insurance = relationship("InsurancePolicy", back_populates="registration", uselist=False)
    incidents = relationship("IncidentReport", back_populates="registration")


class Warranty(Base):
    __tablename__ = "WARRANTY"
    
    warranty_id = Column(Integer, primary_key=True, autoincrement=True)
    registration_id = Column(String(20), ForeignKey("GADGET_REGISTRATION.registration_id"))
    start_date = Column(Date)
    end_date = Column(Date)
    warranty_type = Column(String(50))
    provider = Column(String(100))
    terms = Column(Text)
    
    registration = relationship("GadgetRegistration", back_populates="warranty")


class InsurancePolicy(Base):
    __tablename__ = "INSURANCE_POLICY"
    
    policy_id = Column(Integer, primary_key=True, autoincrement=True)
    registration_id = Column(String(20), ForeignKey("GADGET_REGISTRATION.registration_id"))
    policy_number = Column(String(50), unique=True)
    provider = Column(String(100))
    start_date = Column(Date)
    end_date = Column(Date)
    coverage_amount = Column(Numeric(10, 2))
    premium = Column(Numeric(10, 2))
    status = Column(String(20), default="Active")
    
    registration = relationship("GadgetRegistration", back_populates="insurance")


class IncidentReport(Base):
    __tablename__ = "INCIDENT_REPORT"
    
    incident_id = Column(Integer, primary_key=True, autoincrement=True)
    registration_id = Column(String(20), ForeignKey("GADGET_REGISTRATION.registration_id"))
    student_id = Column(String(20), ForeignKey("STUDENT.student_id"))
    incident_date = Column(Date)
    incident_type = Column(String(50))
    description = Column(Text)
    location = Column(String(200))
    police_report_number = Column(String(50))
    status = Column(String(20), default="Pending")
    resolution_date = Column(Date)
    
    registration = relationship("GadgetRegistration", back_populates="incidents")
    student = relationship("Student", back_populates="incidents")