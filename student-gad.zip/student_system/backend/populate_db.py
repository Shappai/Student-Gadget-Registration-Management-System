"""
Populate database with sample data
Run this AFTER starting the server once to create tables
"""

import requests
from datetime import datetime, timedelta

BASE_URL = "http://127.0.0.1:8000/api"

print("🚀 Populating database with sample data...")

# Departments
print("\n📚 Creating departments...")
departments = [
    {"department_code": "CSC", "department_name": "Computer Science", "faculty": "Science", "hod_name": "Dr. John Smith", "contact_email": "csc@university.edu"},
    {"department_code": "ENG", "department_name": "Engineering", "faculty": "Engineering", "hod_name": "Prof. Mary Johnson", "contact_email": "eng@university.edu"},
    {"department_code": "BUS", "department_name": "Business Administration", "faculty": "Management", "hod_name": "Dr. Peter Williams", "contact_email": "bus@university.edu"},
    {"department_code": "MED", "department_name": "Medicine", "faculty": "Medical Sciences", "hod_name": "Prof. Sarah Davis", "contact_email": "med@university.edu"},
    {"department_code": "LAW", "department_name": "Law", "faculty": "Law", "hod_name": "Dr. Michael Brown", "contact_email": "law@university.edu"},
]

# Note: You'll need to add departments directly to database since we don't have POST endpoint for them
# For now, let's focus on students and registrations

# Students
print("\n👥 Creating students...")
students = [
    {"student_id": "STU2024001", "first_name": "James", "last_name": "Anderson", "email": "james.anderson@student.edu", "phone_number": "08012345601", "department_code": "CSC", "level": "300 Level", "enrollment_date": "2022-09-01", "status": "Active", "emergency_contact": "Mrs. Anderson", "emergency_phone": "08098765401"},
    {"student_id": "STU2024002", "first_name": "Emily", "last_name": "Taylor", "email": "emily.taylor@student.edu", "phone_number": "08012345602", "department_code": "CSC", "level": "200 Level", "enrollment_date": "2023-09-01", "status": "Active", "emergency_contact": "Mr. Taylor", "emergency_phone": "08098765402"},
    {"student_id": "STU2024003", "first_name": "David", "last_name": "Martinez", "email": "david.martinez@student.edu", "phone_number": "08012345603", "department_code": "ENG", "level": "400 Level", "enrollment_date": "2021-09-01", "status": "Active", "emergency_contact": "Mrs. Martinez", "emergency_phone": "08098765403"},
    {"student_id": "STU2024004", "first_name": "Sophie", "last_name": "Wilson", "email": "sophie.wilson@student.edu", "phone_number": "08012345604", "department_code": "BUS", "level": "100 Level", "enrollment_date": "2024-09-01", "status": "Active", "emergency_contact": "Mr. Wilson", "emergency_phone": "08098765404"},
    {"student_id": "STU2024005", "first_name": "Daniel", "last_name": "Moore", "email": "daniel.moore@student.edu", "phone_number": "08012345605", "department_code": "MED", "level": "300 Level", "enrollment_date": "2022-09-01", "status": "Active", "emergency_contact": "Dr. Moore", "emergency_phone": "08098765405"},
]

for student in students:
    try:
        response = requests.post(f"{BASE_URL}/students", json=student)
        if response.status_code == 200:
            print(f"✅ Created student: {student['student_id']}")
        else:
            print(f"❌ Failed to create student: {student['student_id']}")
    except Exception as e:
        print(f"❌ Error: {e}")

# Categories (need to be added directly to database)
print("\n📱 Note: Categories need to be added to database manually")
print("Run this SQL in MySQL:")
print("""
INSERT INTO GADGET_CATEGORY (category_name, description, specifications) VALUES
('Laptop', 'Personal computers for academic work', 'RAM, Processor, Storage, Screen Size'),
('Smartphone', 'Mobile phones for communication', 'OS, RAM, Storage, Camera'),
('Tablet', 'Portable touchscreen devices', 'Screen Size, OS, Storage'),
('Smartwatch', 'Wearable smart devices', 'OS, Battery Life, Features');
""")

# Registrations
print("\n🔖 Creating registrations...")
registrations = [
    {
        "student_id": "STU2024001",
        "category_id": 1,
        "device_name": "MacBook Pro",
        "brand": "Apple",
        "model": "M2 Pro",
        "serial_number": "SN-APPLE-001",
        "purchase_date": "2023-08-15",
        "purchase_price": 1200000.00,
        "color": "Space Gray",
        "condition": "Excellent",
        "payment_amount": 5000.00,
        "payment_method": "Bank Transfer"
    },
    {
        "student_id": "STU2024002",
        "category_id": 2,
        "device_name": "iPhone 14 Pro",
        "brand": "Apple",
        "model": "14 Pro",
        "serial_number": "SN-APPLE-002",
        "imei_number": "356789012345678",
        "purchase_date": "2023-09-20",
        "purchase_price": 850000.00,
        "color": "Deep Purple",
        "condition": "Excellent",
        "payment_amount": 5000.00,
        "payment_method": "Card Payment"
    },
]

for reg in registrations:
    try:
        response = requests.post(f"{BASE_URL}/registrations", json=reg)
        if response.status_code == 200:
            print(f"✅ Created registration for: {reg['student_id']}")
        else:
            print(f"❌ Failed to create registration for: {reg['student_id']}")
    except Exception as e:
        print(f"❌ Error: {e}")

print("\n✅ Database population complete!")
print("\n📊 Check your data:")
print(f"Students: {BASE_URL}/students")
print(f"Registrations: {BASE_URL}/registrations")